# NOT EDIT NOT EDIT NOT EDIT NOT EDIT #


#!/usr/bin/python3

# -*- coding: utf-8 -*-


#/// INITIAL VARIABLES (IMPORTS)
import Tkinter
import sys
import argparse
import os
import httplib
import subprocess
import re
import urllib2
import socket
import urllib
import sys
import json
import telnetlib
import glob
import random
import Queue
import threading
import base64
import time
import ConfigParser
from sys import argv
from commands import *
from getpass import getpass
from xml.dom import minidom
from urlparse import urlparse
from optparse import OptionParser
from time import gmtime, strftime, sleep
from os import path
#/// CHECK ROOT
if os.geteuid() != 0:
    exit("\033[1;31;1mATTENTION! ZJOUNBLOD NEED ROOT MODE FOR WORK!")





#/// messages again menu repeat
message2 = "<=============================================>"
def typewriter(message2):
	for char in message2:
		sys.stdout.write(char)
		sys.stdout.flush()
		time.sleep(0.04)	
#///
#/// ELEGANT CLEAN
os.system('clear')




#///
def clearScr():
    os.system('clear')

#///
class zjounblod:
    def __init__(self):
        clearScr()
        print("\033[1;37;1m ")
        print (\
        	"""
        	          `                                                                     
            `-+ds          `ddhysoo+/::-.`                                      
           `hmNmmo+osyho//+dNmmmdddhhhhddddhys+/:-`                             
           .dmNmmdyssoydmdmmmdhhyssooooooooossyyyyhhyo+:-`                      
           `hdNd/``````:hhys+:.`````````````````````.-:/+oo+/-`                 
            `:Nd/     .+/.``                             ```.-//:-`             
             -Nh+     ``                                       ```..`           
             .mhs                      `-:.                         `           
             `ddh                     `yNMm/`                                   
              omy.                   .hMMMMNh/`                                 
              -my/                  `dMMMMMMNNy`                                
              `yh+                 `oMMMMMMMMNNy`                               
               /ds                 /dMMMMMMMMMNmy                               
               -dh.               .dmMMMMMMMMMNmd`                              
               `hh:              `hNNMMMMMMMMNNNN/``                            
                +d+             .yNMNMMMMMMMMMNNNNhys/.`                        
                ohs`          `+mNMMMMMMMMMMMMMNNNNNNNdy:`                      
               .mhso:       `:dNMMMMMMMMMMMMMMMMNNNNNNNNNy:`                    
               +hddh.     `:hNNMMMMMMMMMMMMMMMMMMNNNNNMMNNNy.                   
               :NMNN:    .sNMNNNMMMMMMMMMMMMMMMMMMMNNNMNMMNNm/`                 
               `hNhmd+-`/mMNNMMMMMMMMMMMMMMMMMMMMMMMNMMMMMMNMNy-`               
                `:omNNNdMMNNMMMMMMMMMMMMMMMMMMMMMMMMMMNNNMMMMMNNs               
                  -mmMMMMMMMMMMMMMMMMMMMMMMMMNdmNmNNNNmhmNNNNNMNN.              
                  .hmMMMMMMMMMMMMMMMMMMMMMNdddddmmmNMMmdmNNNNNNMN/              
                   omNMMMMMMMMMMMMMMMMMMNmhhddmmNmdmNMMNmNNNNNmmMd`             
                   .::::::::::::::::::::::-::.:::-::::::::::::::::` 
        	""")
        print ("                         Z J O U N B L O D        M E N U                    \n")
        menu = ' [00] INFORMATION\n'
        menu +=' [01] EXPLOITING\n'
        menu +=' [02] EXIT\n'
        print(menu) 

        select = raw_input("Select a Option: ")
        if select == "0" or select == "00":
    	    print("New version is coming soon!")
    	    time.sleep(5)
    	    zjounblod()	
        if select == "1" or select == "01":
    	    os.system('clear')
    	    print(\
    		    """
    		    [1] INSTALL EXPLOITING TOOLS #1
    		    [2] OPEN EXPLOITING TOOLS #1
    		    [3] UPDATE EXPLOITING TOOLS #1
    		    [4] BACK TO MENU
    		    """)
    	    selection_exploiting = raw_input("Select a Option: ")
    	    if selection_exploiting == "1":
    		    typewriter(message2)
    		    os.system('clear')
    		    os.system('chmod +x setup.sh')
    		    os.system('./setup.sh')
    		    zjounblod()
    	    if selection_exploiting == "2":
    		    typewriter(message2)
    		    os.system('clear')
    		    os.system('chmod +x zjounblod.sh')
    		    os.system('./zjounblod.sh')
    		    zjounblod()
    	    if selection_exploiting == "3":
    		    typewriter(message2)
    		    os.system('clear')
    		    os.system('chmod +x update.sh')
    		    os.system('./update')
    		    zjounblod()
    	    if selection_exploiting == "4":
    		    zjounblod()
    	       	

        clearScr()
        if select == "\r" or select == "\n" or select == "" or select == " ":
            self.__init__()
        else:
            try:
                print(os.system(choice))
            except:
                pass
#&&&


installmessage = "[C H E C K I N G        I N S T A L L]\n"


#/// CHECK INSTALL

def typewriter(installmessage):
	for char in installmessage:
		sys.stdout.write(char)
		sys.stdout.flush()
		time.sleep(0.04)	

typewriter(installmessage)
print          ("_______________________________________\n")



def CheckData():

   print ("Core File Exist (ZJOUNBLOD.SH) ==>IMPORTANT: " + str(path.exists('zjounblod.sh')))
   print ("Setup File Exist (SETUP.SH) ==> IMPORTANT: ") + str(path.exists('setup.sh'))
   print ("Update File Exist (UPDATE): ") + str(path.exists('update'))
   print ("Powerfull File Exist (POWERFULL.SH): ") + str(path.exists('powerfull.sh'))
   print ("Grab File Exist (GRAB.SH): ") + str(path.exists('grab.sh'))
   print ("Read Me File Exist (READ ME.TXT): ") + str(path.exists('READ ME.txt'))
   print ("Version File Exist (VERSION.TXT): ") + str(path.exists('version'))
   print ("Prog-C File Exist (PROG.C): ") + str(path.exists('prog.c'))
   print ("Prog.C.Backup File Exist (PROG.C.BACKUP): ") + str(path.exists('prog.c.backup'))
   print ("Java Folder Exist: " + str(path.exists('java')))
   print ("Tools Folder Exists: " + str(path.exists('tools')))
   print ("Config Folder Exist: ") + str(path.exists('config'))
   print ("Autorun Folder Exist: ") + str(path.exists('autorun'))
   print ("Logs Folder Exist: ") + str(path.exists('logs'))
   print ("Temporaly Folder Exist: ") + str(path.exists('temp'))
   print ("Lists Folder Exist: ") + str(path.exists('lists'))
   print ("PE Folder Exist: ") + str(path.exists('PE'))
   print ("PostExploit Folder Exist: ") + str(path.exists('postexploit'))
   print ("Fix File Exist (zjounblod dont open in normal terminal fix.TXT) ==> IMPORTANT: ") + str(path.exists('zjounblod dont open in normal terminal fix.txt'))

if __name__== "__main__":
   CheckData()

if str(path.exists('zjounblod.sh')) == "False":
   print("\033[1;31;1m")
   print("[001] ZJOUNBLOD.SH DONT EXIST!  [NEED INSTALL OR DOWNLOAD AGAIN]")

if str(path.exists('setup.sh')) == "False":
   print("\033[1;31;1m")
   print("[002] SETUP.SH DONT EXIST!  [NEED INSTALL OR DOWNLOAD AGAIN]")

if str(path.exists('update')) == "False":
   print("\033[1;31;1m")
   print("[003] UPDATE DONT EXIST!  [NEED INSTALL OR DOWNLOAD AGAIN]")

if str(path.exists('powerfull.sh')) == "False":
   print("\033[1;31;1m")
   print("[004] POWERFULL.SH DONT EXIST!  [NEED INSTALL OR DOWNLOAD AGAIN]")

if str(path.exists('grab.sh')) == "False":
   print("\033[1;31;1m ")
   print("[005] GRAB.SH DONT EXIST!  [NEED INSTALL OR DOWNLOAD AGAIN]")

if str(path.exists('READ ME.txt')) == "False":
   print("\033[1;31;1m")	
   print("[006] READ ME.txt DONT EXIST!  [:Make Again:] | (Y/N)")
   select = raw_input("")  
   if select == "Y" or select == "y":
   	os.system ('> READ ME.txt')

if str(path.exists('version')) == "False":
   print("\033[1;31;1m")
   print("[007] Version.txt DONT EXIST!  [:Make Again:] | (Y/N)")
   select = raw_input("")  
   if select == "Y" or select == "y":
   	os.system ('> version')

if str(path.exists('prog.c')) == "False":
   print("\033[1;31;1m ")
   print("[009] PROGR.C DONT EXIST!  [NEED INSTALL OR DOWNLOAD AGAIN] [DONT DAMAGE THE PROCES]")

if str(path.exists('prog.c.backup')) == "False":
   print("\033[1;31;1m ")

   print("[010] PROGR.C.BACKUP DONT EXIST!  [NEED INSTALL OR DOWNLOAD AGAIN] [DONT DAMAGE THE PROCES]")
if str(path.exists('java')) == "False":
   print("\033[1;31;1m ")

   print("[011] JAVA FOLDER DONT EXIST!  [:Make Again:] | (Y/N)")
   select = raw_input("")  
   if select == "Y" or select == "y":
   	os.system ('mkdir java')

if str(path.exists('tools')) == "False":
   print("\033[1;31;1m ")
   print("[012] TOOLS FOLDER DONT EXIST!  [:Make Again:] | (Y/N)")
   select = raw_input("")  
   if select == "Y" or select == "y":
   	os.system ('mkdir tools')

if str(path.exists('config')) == "False":
   print("\033[1;31;1m ")
   print("[012] CONFIG FOLDER DONT EXIST!  [:Make Again:] | (Y/N)")
   select = raw_input("")  
   if select == "Y" or select == "y":
   	os.system ('mkdir config')

if str(path.exists('autorun')) == "False":
   print("\033[1;31;1m")
   print("[013] AUTORUN FOLDER DONT EXIST!  [:Make Again:] | (Y/N)")
   select = raw_input("")  
   if select == "Y" or select == "y":
   	os.system ('mkdir autorun')

if str(path.exists('logs')) == "False":
   print("\033[1;31;1m ")
   print("[014] LOGS FOLDER DONT EXIST!  [:Make Again:] | (Y/N)")
   select = raw_input("")  
   if select == "Y" or select == "y":
   	os.system ('mkdir logs')

if str(path.exists('temp')) == "False":
   print("\033[1;31;1m ")
   print("[015] TEMPORALY FOLDER DONT EXIST!  [:Make Again:] | (Y/N)")
   select = raw_input("")  
   if select == "Y" or select == "y":
   	os.system ('mkdir temp')

if str(path.exists('lists')) == "False":
   print("\033[1;31;1m ")
   print("[016] LISTS FOLDER DONT EXIST!  [:Make Again:] | (Y/N)")
   select = raw_input("")  
   if select == "Y" or select == "y":
   	os.system ('mkdir lists')

if str(path.exists('PE')) == "False":
   print("\033[1;31;1m ")
   print("[017] PE FOLDER DONT EXIST!  [:Make Again:] | (Y/N)")
   select = raw_input("")  
   if select == "Y" or select == "y":
   	os.system ('mkdir PE')

time.sleep (8)
#///



#///messages
os.system('clear')
message1 = "Welcome my friend, You use now zjounblod, Accept terms and conditions for continue:\n\
 Terms: ZJOUNBLOD - MALWARE ~ SPY ~ ATTACK ~\n\
 Conditions: Nothing Here\n\
 "
message2 = "<=============================================>" 
message3 = "                         Z J O U N B L O D        M E N U                    \n"

#///



#/// DEF VARS
def typewriter(message1):
	for char in message1:
		sys.stdout.write(char)
		sys.stdout.flush()
		time.sleep(0.04)				    
#///		


print("\033[1;31;1m \n")
print(\
	"""
              `:+syhdmmmmmmmdhys+-`               
          `/ydmddhhhhhhddddddhhddmmds/`           
       `/hmdhhhddmNNMMMMMMMMMMMMNNmddmmh/`        
     .omdhhhmNMMNNNmmmmNNMMNy++osydNNNNmmmo.      
`- `+mdhhdNMMMMMddNNNmmdhdmMMd.    `-/ymNNNNo`    
oN+hmhhmNMMMMmhMdhNNysoshmdhNMm.       `:smMMd-   
yMMdhdNMMMMd/`sMddMy:::-`/dmhNMd          `/dMm-  
-MdhmMMMMm/` .Nmhmm/://:-/hMddMM/           `+mN- 
-dmmMMMMy.  .hNddNMmdmdddmMMmhmMh             .yd`
 `sMMMMd` `+mNddNsshyssohdssmhdMN               o+
   /NMNMy.`dMmhdNNs+//d//osNMhdMM.               :
    .+:mMmshMMNdhNMMdyhhhMMMmhdMMdyo/             
      .oMMNddMMMdhNMMMMMMMNddmMMNdmMM:.           
   .odmNmmNmhdMMNhhMMMMMNddmMMMmddNNmNmds.        
   `yMNdhhdmdhdNMmhmMMNmdmNMMmdhdmdhhdNMy`        
    `/mNdhdmNNNNMMhdMmddNMMNmdhhdhhhmNh:          
      `omNdhmNMMMMmdddNMMMNmdddhhdmNy-            
        `+dNmmmNMMNdmMMNNmmNNNmmNh+`              
           -odNNNMMNMMMMMMMMMNh+.                 
              `/smMMMMMMMMNy/`                    
                  ./smNh+- """)
print("\033[1;37;1m ")
print("--------------------------------------------------------------------------------")
typewriter(message1)		
print("--------------------------------------------------------------------------------")
print("\033[1;37;1m ")
def typewriter(message2):
	for char in message2:
		sys.stdout.write(char)
		sys.stdout.flush()
		time.sleep(0.04)		
continue1 = raw_input("Continue? (Y/N): ")
if continue1 == "Y" or continue1 == "y":
    typewriter(message2)
    print("\n")
    print("\033[1;37;1mLOADING COMPLETE")
    time.sleep(2)
    os.system('clear')
    print("")

    print(\
    	"""

                                                                                
          `                                                                     
            `-+ds          `ddhysoo+/::-.`                                      
           `hmNmmo+osyho//+dNmmmdddhhhhddddhys+/:-`                             
           .dmNmmdyssoydmdmmmdhhyssooooooooossyyyyhhyo+:-`                      
           `hdNd/``````:hhys+:.`````````````````````.-:/+oo+/-`                 
            `:Nd/     .+/.``                             ```.-//:-`             
             -Nh+     ``                                       ```..`           
             .mhs                      `-:.                         `           
             `ddh                     `yNMm/`                                   
              omy.                   .hMMMMNh/`                                 
              -my/                  `dMMMMMMNNy`                                
              `yh+                 `oMMMMMMMMNNy`                               
               /ds                 /dMMMMMMMMMNmy                               
               -dh.               .dmMMMMMMMMMNmd`                              
               `hh:              `hNNMMMMMMMMNNNN/``                            
                +d+             .yNMNMMMMMMMMMNNNNhys/.`                        
                ohs`          `+mNMMMMMMMMMMMMMNNNNNNNdy:`                      
               .mhso:       `:dNMMMMMMMMMMMMMMMMNNNNNNNNNy:`                    
               +hddh.     `:hNNMMMMMMMMMMMMMMMMMMNNNNNMMNNNy.                   
               :NMNN:    .sNMNNNMMMMMMMMMMMMMMMMMMMNNNMNMMNNm/`                 
               `hNhmd+-`/mMNNMMMMMMMMMMMMMMMMMMMMMMMNMMMMMMNMNy-`               
                `:omNNNdMMNNMMMMMMMMMMMMMMMMMMMMMMMMMMNNNMMMMMNNs               
                  -mmMMMMMMMMMMMMMMMMMMMMMMMMNdmNmNNNNmhmNNNNNMNN.              
                  .hmMMMMMMMMMMMMMMMMMMMMMNdddddmmmNMMmdmNNNNNNMN/              
                   omNMMMMMMMMMMMMMMMMMMNmhhddmmNmdmNMMNmNNNNNmmMd`             
                   .::::::::::::::::::::::-::.:::-::::::::::::::::` 
    	""")
    def typewriter(message3):
	    for char in message3:
		    sys.stdout.write(char)
		    sys.stdout.flush()
		    time.sleep(0.04)	
    typewriter(message3)
    print("\n")

    menu = ' [00] INFORMATION\n'
    menu +=' [01] EXPLOITING\n'
    menu +=' [02] EXIT\n'
    print(menu) 

    select = raw_input("Select a Option: ")
    if select == "0" or select == "00":
    	print("New version is coming soon!")
    	time.sleep(5)
    	zjounblod()	
    if select == "1" or select == "01":
    	os.system('clear')
    	print(\
    		"""
    		[1] INSTALL EXPLOITING TOOLS #1
    		[2] OPEN EXPLOITING TOOLS #1
    		[3] UPDATE EXPLOITING TOOLS #1
    		[4] BACK TO MENU
    		""")
    	selection_exploiting = raw_input("Select a Option: ")
    	if selection_exploiting == "1":
    		typewriter(message2)
    		os.system('clear')
    		os.system('chmod +x setup.sh')
    		os.system('./setup.sh')
    		zjounblod()
    	if selection_exploiting == "2":
    		typewriter(message2)
    		os.system('clear')
    		os.system('chmod +x zjounblod.sh')
    		os.system('./zjounblod.sh')
    		zjounblod()
    	if selection_exploiting == "3":
    		typewriter(message2)
    		os.system('clear')
    		os.system('chmod +x update.sh')
    		os.system('./update')
    		zjounblod()
    	if selection_exploiting == "4":
    		zjounblod()
    	       	
    	     	

    	
    


else:
	os.system('clear')
	print ("\033[3;34;40mGOOD BYE            \033[1;31;40mZJOUNDBLOD             \033[1;33;40mWAIT YOU")